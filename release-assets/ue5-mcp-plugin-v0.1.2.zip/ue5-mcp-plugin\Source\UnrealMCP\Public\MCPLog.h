#pragma once

#include "CoreMinimal.h"

UNREALMCP_API DECLARE_LOG_CATEGORY_EXTERN(LogUnrealMCP, Log, All);
