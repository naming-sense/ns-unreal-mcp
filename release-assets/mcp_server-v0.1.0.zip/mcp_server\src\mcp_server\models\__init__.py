"""Model definitions for UE transport messages."""
